package com.zybooks.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.inventoryapp.helper.Helper;
import com.zybooks.inventoryapp.model.UserDto;
import com.zybooks.inventoryapp.model.ValidationResult;
import com.zybooks.inventoryapp.repo.InventoryDatabase;

public class LoginActivity extends AppCompatActivity {
    private Button buttonRegister, buttonLogin;
    private EditText editUserName, editPassword;
    private InventoryDatabase inventoryDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        inventoryDatabase = new InventoryDatabase(this);
        editUserName =findViewById(R.id.edUserName);
        editPassword = findViewById(R.id.edPwd);

        buttonRegister = findViewById(R.id.btnRegister);
        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an intent to start SecondActivity
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);  // Start the second activity
            }
        });

        buttonLogin = findViewById(R.id.btnLogin);
        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ValidationResult valid = IsValidToLogin();
                if(!valid.hasError()){
                    // Create an intent to start InventoryActivity
                    Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
                    startActivity(intent);  // Start the second activity
                }else{
                    Helper.SnackbarNotify(v,valid.getErrorMessage());
                }
            }
        });
    }

    private ValidationResult IsValidToLogin(){
        ValidationResult vr = new ValidationResult(false,"");

        if(editUserName.getText().length() == 0){
            vr.setHasError(true);
            vr.setErrorMessage("You must enter Username.");
            return vr;
        }

        if(editPassword.getText().toString().length() == 0){
            vr.setHasError(true);
            vr.setErrorMessage("Password can't be empty.");
            return vr;
        }

        UserDto res = inventoryDatabase.getUserByUserName(editUserName.getText().toString());
        if(res != null && res.getId()>0){
            if(!res.getPassword().equals( editPassword.getText().toString())){
                vr.setHasError(true);
                vr.setErrorMessage("Please check your account.");
                return vr;
            }
        }

        return vr;
    }
}